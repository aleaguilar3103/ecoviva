import { LOGOS } from './logos';

export default function ApplicationsSection() {
  return (
    <section className="bb-section" id="aplicaciones">
      <div className="bb-section-header bb-reveal">
        <p className="bb-section-label">06 — Aplicaciones</p>
        <h2 className="bb-section-title">La marca en acción</h2>
        <p className="bb-section-desc">
          Ejemplos de cómo la identidad cobra vida en diferentes soportes y contextos.
        </p>
      </div>

      <div className="bb-app-grid bb-reveal">
        {/* Business card */}
        <div className="bb-app-card">
          <div className="bb-app-preview" style={{ background: 'var(--off-white)' }}>
            <div className="bb-biz-card">
              <img src={LOGOS.blancoHorizontal} alt="Logo" />
              <div className="bb-biz-card-text">
                Nombre Apellido
                <br />
                Asesor de Inversión
                <br />
                +506 0000 0000
                <br />
                info@ecovivadesarrollos.com
              </div>
            </div>
          </div>
          <div className="bb-app-card-info">
            <h4 className="bb-app-card-title">Tarjeta de presentación</h4>
            <p className="bb-app-card-desc">
              Fondo oscuro con logo en blanco. Tipografía ligera para datos de contacto.
            </p>
          </div>
        </div>

        {/* Letterhead */}
        <div className="bb-app-card">
          <div className="bb-app-preview" style={{ background: 'var(--off-white)' }}>
            <div className="bb-letterhead">
              <img src={LOGOS.grisHorizontal} alt="Logo" />
              {[100, 90, 95, 60, 0, 100, 85, 92, 40].map((w, i) =>
                w === 0 ? (
                  <div key={i} style={{ height: '0.8rem' }} />
                ) : (
                  <div
                    key={i}
                    className="bb-letterhead-line"
                    style={{ width: `${w}%` }}
                  />
                )
              )}
            </div>
          </div>
          <div className="bb-app-card-info">
            <h4 className="bb-app-card-title">Hoja membretada</h4>
            <p className="bb-app-card-desc">
              Versión gris oscuro del logo sobre fondo blanco. Limpia y profesional.
            </p>
          </div>
        </div>

        {/* Sign */}
        <div className="bb-app-card">
          <div className="bb-app-preview bb-sign-mockup">
            <img src={LOGOS.blancoHorizontal} alt="Señalización" />
          </div>
          <div className="bb-app-card-info">
            <h4 className="bb-app-card-title">Señalización de proyecto</h4>
            <p className="bb-app-card-desc">
              Logo blanco sobre fondo degradado verde a teal. Máximo contraste y visibilidad.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
