# EcoViva Desarrollos — Brand Book (React + Vite)

## Estructura de archivos

```
src/
├── components/
│   └── BrandBook/
│       ├── index.jsx              ← Componente principal (importar este)
│       ├── Nav.jsx                ← Navegación fija con auto-hide
│       ├── Hero.jsx               ← Hero con logo y animación
│       ├── LogoSection.jsx        ← Versiones del logo + zona de protección + usos incorrectos
│       ├── ColorSection.jsx       ← Paleta de colores con click-to-copy
│       ├── TypographySection.jsx  ← Tipografías y escala
│       ├── VoiceSection.jsx       ← Tono de voz, principios, do/don't
│       ├── PersonalitySection.jsx ← Arquetipos y rasgos
│       ├── ApplicationsSection.jsx← Mockups de aplicaciones
│       ├── Footer.jsx             ← Footer
│       ├── logos.js               ← URLs de logos en CDN
│       └── useScrollReveal.js     ← Hook para animaciones al scroll
└── styles/
    └── BrandBook.css              ← Todos los estilos (prefijo bb-)
```

## Instalación

1. Copia la carpeta `components/BrandBook/` a tu proyecto en `src/components/`
2. Copia `styles/BrandBook.css` a `src/styles/`
3. Agrega la fuente Montserrat en tu `index.html`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
```

4. Importa y usa el componente:

```jsx
import BrandBook from './components/BrandBook';

function App() {
  return <BrandBook />;
}
```

## Dependencias

- React 18+
- Solo usa hooks nativos de React (`useState`, `useEffect`, `useRef`, `useCallback`)
- Sin dependencias externas adicionales

## Notas

- Todos los estilos usan el prefijo `bb-` para evitar conflictos con tu CSS existente
- Las imágenes se cargan desde CDN (filesafe.space) — no se necesitan assets locales
- El scroll-reveal usa IntersectionObserver nativo
- El nav se oculta al hacer scroll hacia abajo y reaparece al subir
- Los colores son click-to-copy al portapapeles
- Europa Grotesk SH es una fuente personalizada — el componente usa Montserrat como fallback. Si tenés el archivo .woff2 de Europa Grotesk, agregá un @font-face en el CSS
